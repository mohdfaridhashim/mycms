 						<div class="thumbnail">
				            <h4>About</h4>
				            <p>Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>
				        </div>
				        <div role="navigation">
			              <ul class="list-group">
				            <li class="list-group-item active">Coffee</li>
				            <a href="index.php" class="list-group-item">Home</a>            
				            <a href="index.php?p=1" class="list-group-item">Register</a>
				            <a href="index.php?p=1000" class="list-group-item">Logout</a>				            
				            <a href="http://getbootstrap.com/examples/offcanvas/#" class="list-group-item">Link</a>
				          </ul>
			        	</div><!--/span-->