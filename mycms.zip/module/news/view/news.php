				<!-- News -->
				<div>
					&nbsp;
					<h3>Latest News</h3>
					<hr>
				</div>
				<div class="marketing">

			        	<div>
				          <h2>Heading</h2>
				          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
				          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
				        </div>

			        	<div>
				          <h2>Heading</h2>
				          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
				          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
				        </div>
			    </div>