<?php

include 'view/news.php'
?>