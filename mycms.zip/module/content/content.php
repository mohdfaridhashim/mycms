<?php





		url_routing(define_module_combine('1000'),TITLE."&Welcome to my humble Page.");
		//echo $page;
		include_once 'view/content.php';
		url_routing(define_module_combine('1100'));
		url_routing(define_module_combine('1200'));
		url_routing(define_module_combine('1100'));
		//echo Generate_ID();
	
	



	
?>