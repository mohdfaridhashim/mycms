<?php
$split = explode("&",$message);
include 'view/jumbo.php';

?>