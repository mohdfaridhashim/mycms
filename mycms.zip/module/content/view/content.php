			        <!--Body content-->
			        <!-- featured article -->
			    <div class="marketing">

					<div class="col-md-4">
						<div class="thumbnail">
				          <h2>Heading</h2>
				          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
				          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
				        </div>
			        </div>

					<div class="col-md-4">
						<div class="thumbnail">
				          <h2>Heading</h2>
				          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
				          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
			      		</div>
			        </div>

					<div class="col-md-4">
						<div class="thumbnail">
				          <h2>Heading</h2>
				          <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
				          <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
				        </div>
			    	</div>

				</div>

			    