<?php

include 'view/gallery.php';
?>