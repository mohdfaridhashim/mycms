<?php
    url_routing(define_module_combine('1000'),"Registration form&");
    include 'view/registerform.php';
?>