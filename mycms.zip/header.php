<?php include_once 'config.php'; ?>
<!DOCTYPE html>
<head>
<title><?php echo TITLE ?></title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
<link href="style/style.css" rel="stylesheet" type="text/css" />

</head>