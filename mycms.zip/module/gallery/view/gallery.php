<!-- Gallery-->
			    <div>
				    <h3>Gallery</h3>
				    <hr>
				</div>

				<div>
						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>

						  <div class="col-xs-6 col-md-3">
						    <a href="#" class="thumbnail">
						      <img data-src="holder.js/100%x180" alt="...">
						    </a>
						  </div>