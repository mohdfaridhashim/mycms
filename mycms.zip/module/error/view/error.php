	<!--Body content-->
			      	<!--Title and description-->
			          <div class="jumbotron">
			          	<center>
			            <h1>ERROR</h1>
			            <p>Sorry, the requested page is not found</p>
			            </center>
			          </div>
			        <!--Body content-->
			        <!-- featured article -->
			        <!-- News -->
					<div class="panel panel-danger">
						<div class="panel-body">
					          <center>
					          	<h2>OH, oh!</h2>

					          </center>
					        </div>
				    </div>