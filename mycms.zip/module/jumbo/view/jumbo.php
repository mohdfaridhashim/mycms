			          <div class="jumbotron">
			            <h1><?php echo $split[0]; ?></h1>
			            <p><?php echo $split[1]; ?></p>
			          </div>